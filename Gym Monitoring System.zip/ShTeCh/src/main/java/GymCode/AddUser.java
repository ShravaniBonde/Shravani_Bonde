package GymCode;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/User")
public class AddUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");
	        
	        String FirstName = request.getParameter("FirstName");
	        String LastName = request.getParameter("LastName");
	        String email  = request.getParameter("email");
	        String packageName = request.getParameter("packageName");
	        String ShiftName = request.getParameter("ShiftName");
	        String DOB = request.getParameter("DOB");
	        String Gender = request.getParameter("Gender");
	        String contact = request.getParameter("contact");
	        String City = request.getParameter("City");
	        String AddressLine1 = request.getParameter("AddressLine1");
	        String AddressLine2 = request.getParameter("AddressLine2");
	        
	        try {
	            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            
	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gymsystem", "root", "Shravani@123#");
	            
	                        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO adduser (FirstName, LastName, email, packageName, ShiftName, DOB, Gender, contact, City, AddressLine1, AddressLine2 ) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
	            pstmt.setString(1, FirstName);
	            pstmt.setString(2, LastName);
	            pstmt.setString(3, email);
	            pstmt.setString(4, packageName);
	            pstmt.setString(5, ShiftName);
	            pstmt.setString(6, DOB);
	            pstmt.setString(7, Gender);
	            pstmt.setString(8, contact);
	            pstmt.setString(9, City);
	            pstmt.setString(10, AddressLine1);
	            pstmt.setString(11, AddressLine2);
	            
	            
	            pstmt.executeUpdate();
	            
	            
	            pstmt.close();
	            conn.close();
	            
	            
	            response.sendRedirect("UserConfirmation.jsp");
	        } catch (Exception e) {
	            e.printStackTrace();
	            response.getWriter().println("Error: " + e.getMessage());
	        }
	    }
	}

       
   
