package GymCode;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.sql.*;
@WebServlet("/Registration")
public class Registration extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String username = request.getParameter("username"); 
        String email= request.getParameter("email");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String phone = request.getParameter("phone");
        String membership = request.getParameter("membership");
        String password = request.getParameter("password");
        String confirm_password = request.getParameter("confirm_password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gymsystem","root","Shravani@123#");

            PreparedStatement stmt = con.prepareStatement("insert into registration(username,email,dob,gender,phone,membership,password,confirm_password) values(?,?,?,?,?,?,?,?)");
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, dob);
            stmt.setString(4, gender);
            stmt.setString(5, phone);
            stmt.setString(6, membership);
            stmt.setString(7, password);
            stmt.setString(8,confirm_password);

            int i = stmt.executeUpdate();
            if (i > 0) {
            	response.sendRedirect("index2.jsp");
            } else {
                response.sendRedirect("Registration.jsp");
            }

            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}


