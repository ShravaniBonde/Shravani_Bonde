package GymCode;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addShift")
public class AddShiftServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String userName = request.getParameter("userName");
        String shiftName = request.getParameter("shiftName");
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        
        // JDBC Connection Parameters
        String url = "jdbc:mysql://localhost:3306/gymsystem";
        String user = "root";
        String password = "Shravani@123#";
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Connect to the database
            Connection conn = DriverManager.getConnection(url, user, password);
            
            // Prepare SQL statement for inserting data
            String sql = "INSERT INTO shift1 (user_name,shift_name, start_time, end_time) VALUES (?,?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, userName);
            statement.setString(2, shiftName);
            statement.setString(3, startTime);
            statement.setString(4, endTime);
            
            // Execute the SQL statement
            statement.executeUpdate();
            
            // Close the connections
            statement.close();
            conn.close();
            
            // Redirect to a success page
            response.sendRedirect("addShift.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            // Handle exceptions
            e.printStackTrace();
            response.sendRedirect("error.html");
        }
    }
}


