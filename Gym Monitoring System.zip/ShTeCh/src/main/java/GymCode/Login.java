package GymCode;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet
{
	private static final String Username = null;
	private static final String Password = null;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		resp.setContentType("text/html");
		
		PrintWriter out = resp.getWriter();
		
		String MyUsername = req.getParameter("Username");
		String MyPassword= req.getParameter("Password");
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gymsystem", "root", "Shravani@123#");
					
					PreparedStatement ps = con.prepareStatement("select * from Registration where Username=? and Password =?");
			        
					ps.setString(1,Username);
			        ps.setString(2,Password);
			        
			        ResultSet rs = ps.executeQuery();
			        if(rs.next())
			        {
			        	HttpSession session = req.getSession();
			        	session.setAttribute("session_name", rs.getString("Username"));
			        	
			        	RequestDispatcher rd = req.getRequestDispatcher("/index2.jsp");
			        	rd.include(req, resp);
			        }
			        else
			        {
			        	
			        	out.print("<h3 style='color:red'> Username and password didn't matched </h3>");
			        	
			        	RequestDispatcher rd = req.getRequestDispatcher("/index2.jsp");
			        	rd.include(req, resp);
			        }
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
        	out.print("<h3 style ='color:red'> "+e.getMessage()+" </h3>");
        	
        	RequestDispatcher rd = req.getRequestDispatcher("/index2.jsp");
        	rd.include(req, resp);
		}
	}
}
