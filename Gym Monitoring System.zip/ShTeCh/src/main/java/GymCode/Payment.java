package GymCode;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Payment")
public class Payment extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        
        String UserName = request.getParameter("UserName");
        String Gender = request.getParameter("Gender");
        String Date = request.getParameter("Date");
        String Amount = request.getParameter("Amount");
        String contact = request.getParameter("contact");
        String Message = request.getParameter("Message");
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gymsystem", "root", "Shravani@123#");
            
                        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Payment (UserName, Gender, Date, Amount, contact, Message) VALUES (?, ?, ?,?,?, ?)");
            pstmt.setString(1, UserName);
            pstmt.setString(2, Gender);
            pstmt.setString(3, Date);
            pstmt.setString(4, Amount);
            pstmt.setString(5, contact);
            pstmt.setString(6, Message);
            
            
            pstmt.executeUpdate();
            
            
            pstmt.close();
            conn.close();
            
            
            response.sendRedirect("PaymentReceipt.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
