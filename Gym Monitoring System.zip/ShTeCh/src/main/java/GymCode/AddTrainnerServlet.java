package GymCode;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Trainner
 */
@WebServlet("/Trainner")
public class AddTrainnerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        
        String trainerName = request.getParameter("trainerName");
        String speciality = request.getParameter("speciality");
        String experience = request.getParameter("experience");
        String contact = request.getParameter("contact");
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gymsystem", "root", "Shravani@123#");
            
                        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO trainer2 (trainerName, speciality, experience, contact) VALUES (?, ?, ?, ?)");
            pstmt.setString(1, trainerName);
            pstmt.setString(2, speciality);
            pstmt.setString(3, experience);
            pstmt.setString(4, contact);
            
            
            pstmt.executeUpdate();
            
            
            pstmt.close();
            conn.close();
            
            
            response.sendRedirect("addTrainner.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
